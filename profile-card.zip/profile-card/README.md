# Profile card

A Pen created on CodePen.

Original URL: [https://codepen.io/Ajani-Abubakar/pen/MYYOXym](https://codepen.io/Ajani-Abubakar/pen/MYYOXym).

